// Runs on her PC. Reads TikTok LIVE comments and passes them to the globe page.
const http=require('http'),https=require('https'),fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const {WebSocketServer,WebSocket}=require('ws');
// The Mac app keeps settings in the user's Application Support folder, because the app bundle itself is read-only.
const DATA=process.env.GT_DATA_DIR||__dirname;
const CFG=path.join(DATA,'config.json');
if(!fs.existsSync(CFG)){try{fs.mkdirSync(DATA,{recursive:true});fs.copyFileSync(path.join(__dirname,'config.json'),CFG)}catch(e){}}
const CFG_DEFAULTS={username:'',source:'auto',signApiKey:'',ssnSession:'',mode:'welcome',visiting:'',phoneRemote:true,remoteKey:'',knownHosts:{},port:8787};
let cfg={...CFG_DEFAULTS};
const writeCfg=()=>{const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG)};
try{cfg={...CFG_DEFAULTS,...JSON.parse(fs.readFileSync(CFG,'utf8'))}}catch(e){console.log('Settings file could not be read. Starting with defaults.')}
if(!/^[a-z0-9]{10}$/.test(cfg.remoteKey)){cfg.remoteKey=crypto.randomBytes(8).toString('hex').slice(0,10);try{fs.writeFileSync(CFG,JSON.stringify(cfg,null,2))}catch(e){}}
process.on('uncaughtException',e=>console.log('Unexpected error, still running: '+(e&&e.message||e)));
process.on('unhandledRejection',e=>console.log('Unexpected error, still running: '+(e&&e.message||e)));
const PUB=path.join(__dirname,'public');
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.jpg':'image/jpeg','.png':'image/png'};
const RETRY=30000;
let status={type:'status',text:'CONNECTING TO TIKTOK',live:false};

// Only the globe page itself may read or change connection details.
const localHost=h=>/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(h||'');
function trusted(req){
  if(!localHost(req.headers.host))return false;
  const o=req.headers.origin;if(!o)return true;
  try{return new URL(o).host===req.headers.host}catch(e){return false}
}
function lanUrls(){const out=[];for(const list of Object.values(os.networkInterfaces()))for(const a of list||[])if(a.family==='IPv4'&&!a.internal&&/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address))out.push('http://'+a.address+':'+cfg.port+'/remote?k='+cfg.remoteKey);return out}
function publicConfig(){return{lastSeen,phone:cfg.phoneRemote?lanUrls():[],phoneRemote:!!cfg.phoneRemote,mode:cfg.mode==='gifting'?'gifting':'welcome',visiting:cfg.visiting||'',username:cfg.username||'',source:cfg.source||'auto',hasSignKey:!!cfg.signApiKey,hasSsn:!!cfg.ssnSession}}
const cleanUser=(v,what)=>{const u=String(v).trim().replace(/^https?:\/\/(www\.)?tiktok\.com\//i,'').replace(/^@/,'').split(/[/?#]/)[0];if(u&&!/^[\w.]{1,40}$/.test(u))throw new Error('That '+what+' is not a valid TikTok username.');return u};
function saveConfig(b){
  if(typeof b.username==='string')cfg.username=cleanUser(b.username,'username');
  if(typeof b.visiting==='string')cfg.visiting=cleanUser(b.visiting,'creator name');
  if(b.mode!==undefined){if(!['welcome','gifting'].includes(b.mode))throw new Error('Unknown mode.');cfg.mode=b.mode}
  if(b.source!==undefined){if(!['auto','direct','tikfinity','ssn'].includes(b.source))throw new Error('Unknown connection source.');cfg.source=b.source}
  if(typeof b.signApiKey==='string'&&b.signApiKey.trim())cfg.signApiKey=b.signApiKey.trim();
  if(typeof b.ssnSession==='string'&&b.ssnSession.trim()){const v=b.ssnSession.trim(),m=v.match(/[?&]session=([^&#\s]+)/);cfg.ssnSession=m?decodeURIComponent(m[1]):v}
  if(typeof b.phoneRemote==='boolean')cfg.phoneRemote=b.phoneRemote;
  if(b.newRemoteKey)cfg.remoteKey=crypto.randomBytes(8).toString('hex').slice(0,10);
  if(b.forgetKeys){cfg.signApiKey='';cfg.ssnSession=''}
  const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG);
}
const server=http.createServer((req,res)=>{
  let url,pathname;
  try{url=new URL(req.url,'http://localhost');pathname=decodeURIComponent(url.pathname)}catch(e){res.statusCode=400;return res.end('Bad request')}
  const fromThisPc=/^(::1|127\.|::ffff:127\.)/.test(req.socket.remoteAddress||'');
  if(!fromThisPc){
    // Other devices on the network (her phone) may only use the phone remote.
    if(!cfg.phoneRemote||!pathname.startsWith('/remote')){res.statusCode=404;return res.end('Not found')}
    return remote(req,res,url,pathname);
  }
  if(pathname.startsWith('/remote'))return remote(req,res,url,pathname);
  if((url.pathname==='/config'||url.pathname==='/comment')&&!trusted(req)){res.statusCode=403;return res.end('Not allowed')}
  if(process.env.GT_TEST==='1'&&url.pathname==='/test-gift'&&req.method==='POST'){let b='';req.on('data',d=>b+=d);req.on('end',()=>{const j=JSON.parse(b);onGift(j.d,j.host,hostProfile(j.info,j.host));res.end('ok')});return}
  if(url.pathname==='/config'){
    res.setHeader('Content-Type','application/json');
    if(req.method==='GET')return res.end(JSON.stringify(publicConfig()));
    if(req.method==='POST'){let b='';req.on('data',d=>{if(b.length<8192)b+=d});req.on('end',()=>{try{saveConfig(JSON.parse(b));res.end(JSON.stringify(publicConfig()));restart()}catch(e){res.statusCode=400;res.end(JSON.stringify({error:e.message||'Those settings could not be saved.'}))}});return}
    res.statusCode=405;return res.end('{}');
  }
  if(req.method==='POST'&&url.pathname==='/comment'){ // manual backup and testing
    let b='';req.on('data',d=>{if(b.length<8192)b+=d});req.on('end',()=>{try{const m=JSON.parse(b);comment(m.user||'viewer',m.text);res.end('ok')}catch(e){res.statusCode=400;res.end('Send JSON with user and text')}});return;
  }
  const file=path.normalize(path.join(PUB,pathname==='/'?'index.html':pathname));
  if(!file.startsWith(PUB+path.sep)||req.method!=='GET'){res.statusCode=403;return res.end()}
  fs.readFile(file,(e,d)=>{if(e){res.statusCode=404;return res.end('Not found')}res.setHeader('Content-Type',TYPES[path.extname(file)]||'application/octet-stream');res.end(d)});
});
// ---------- Phone remote: lets Angela tell the PC which live she is on ----------
let badTries=0,lockedUntil=0,lastGift=null,lastSeen=null,seenKey='';
setInterval(()=>{badTries=0},60000).unref();
function keyOk(k){const a=Buffer.from(String(k||'')),b=Buffer.from(cfg.remoteKey);return a.length===b.length&&crypto.timingSafeEqual(a,b)}
function json(res,code,o){res.statusCode=code;res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(o))}
// Turns a shared TikTok link, a profile link or a typed name into a username. Short links are followed on tiktok.com only.
function followLink(link,hops){
  return new Promise((ok,fail)=>{
    let u;try{u=new URL(link)}catch(e){return fail(new Error('That link could not be read.'))}
    const testHost=process.env.GT_TEST==='1'&&u.hostname==='127.0.0.1';
    if(!testHost&&!(u.protocol==='https:'&&/(^|\.)tiktok\.com$/i.test(u.hostname)))return fail(new Error('Only TikTok links can be used.'));
    const m=u.pathname.match(/\/@([\w.]{1,40})/);if(m)return ok(m[1]);
    if(hops>4)return fail(new Error('That link did not lead to a TikTok profile.'));
    const r=(testHost?http:https).request(u,{method:'GET',timeout:8000,headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}},resp=>{resp.resume();const loc=resp.headers.location;if(resp.statusCode>=300&&resp.statusCode<400&&loc)followLink(new URL(loc,u).href,hops+1).then(ok,fail);else fail(new Error('That link did not lead to a TikTok profile.'))});
    r.on('timeout',()=>r.destroy(new Error('TikTok did not answer. Try the creator name instead.')));r.on('error',e=>fail(e));r.end();
  });
}
async function toUsername(input){
  const t=String(input||'').trim().slice(0,300);
  const link=t.match(/https?:\/\/\S+/);
  if(link)return followLink(link[0].replace(/[).,]+$/,''),0);
  return cleanUser(t,'creator name');
}
// What the phone app saw on the TikTok live screen. Pick the creator: a learned display name first, then an @handle shown in the header area.
function seen(j){
  const arr=v=>Array.isArray(v)?v.slice(0,80).map(x=>String(x).slice(0,80)):[];
  const top=arr(j.top),handles=arr(j.handles).map(h=>h.replace(/^@/,'')).filter(h=>/^[\w.]{2,24}$/.test(h)),sample=arr(j.sample);
  lastSeen={top:top.slice(0,8),handles:handles.slice(0,8),sample:sample.slice(0,40),at:Date.now(),result:''};
  if(cfg.mode!=='gifting'){lastSeen.result='PC is in Welcome Mode';return{result:lastSeen.result}}
  let user='',name='';
  for(const t of top){const k=nameKey(t);if(cfg.knownHosts&&cfg.knownHosts[k]){user=cfg.knownHosts[k];name=t;break}}
  if(!user){const h=top.map(t=>t.match(/^@([\w.]{2,24})$/)).find(Boolean);if(h)user=h[1]}
  if(!user){lastSeen.result=top[0]?'Not recognized yet: '+top[0]:'No creator name found on screen';return{result:lastSeen.result,needShare:!!top[0]}}
  lastSeen.result='Following @'+user;
  if(user.toLowerCase()!==String(cfg.visiting).toLowerCase()){cfg.visiting=user;writeCfg();restart();send({type:'config'})}
  return{result:lastSeen.result,visiting:user,name};
}
function remote(req,res,url,pathname){
  if(!cfg.phoneRemote)return json(res,404,{error:'The phone remote is turned off on the PC.'});
  if(req.method==='GET'&&pathname==='/remote/logo.png'){res.setHeader('Content-Type','image/png');return fs.createReadStream(path.join(PUB,'assets','icon.png')).on('error',()=>res.end()).pipe(res)}
  if(Date.now()<lockedUntil)return json(res,429,{error:'Too many wrong tries. Wait a minute.'});
  const k=url.searchParams.get('k');
  if(!keyOk(k)){if(++badTries>10)lockedUntil=Date.now()+60000;return json(res,403,{error:'This remote link is out of date. Scan the new code on the PC.'})}
  if(req.method==='GET'&&pathname==='/remote'){res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');return fs.createReadStream(path.join(__dirname,'remote.html')).on('error',()=>res.end('Remote page missing.')).pipe(res)}
  if(req.method==='GET'&&pathname==='/remote/logo.png'){res.setHeader('Content-Type','image/png');return fs.createReadStream(path.join(PUB,'assets','icon.png')).on('error',()=>res.end()).pipe(res)}
  if(req.method==='GET'&&pathname==='/remote/status')return json(res,200,{seen:lastSeen&&lastSeen.result,mode:cfg.mode,visiting:cfg.visiting,status:status.text,live:status.live,lastGift});
  if(req.method==='POST'&&pathname==='/remote/seen'){
    let b='';req.on('data',d=>{if(b.length<16384)b+=d});
    req.on('end',()=>{try{json(res,200,seen(JSON.parse(b||'{}')))}catch(e){json(res,400,{error:'The phone sent something unreadable.'})}});
    return;
  }
  if(req.method==='POST'&&pathname==='/remote/visit'){
    let b='';req.on('data',d=>{if(b.length<4096)b+=d});
    req.on('end',async()=>{try{const j=JSON.parse(b||'{}');
      if(j.stop){cfg.visiting=''}else{const u=await toUsername(j.link);if(!u)throw new Error('Paste a TikTok live link or type the creator name.');cfg.visiting=u;cfg.mode='gifting'}
      const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG);restart();send({type:'config'});
      json(res,200,{mode:cfg.mode,visiting:cfg.visiting})}catch(e){json(res,400,{error:e.message||'That did not work.'})}});
    return;
  }
  json(res,404,{error:'Not found'});
}
const wss=new WebSocketServer({server,path:'/events',verifyClient:i=>trusted(i.req)});
wss.on('error',()=>{}); // the listen error is handled once, on the server below
wss.on('connection',ws=>ws.send(JSON.stringify(status)));
function send(m){const t=JSON.stringify(m);for(const c of wss.clients)if(c.readyState===WebSocket.OPEN)c.send(t)}
function setStatus(text,live){status={type:'status',text,live:!!live};send(status);console.log('['+new Date().toLocaleTimeString()+'] '+text)}
function comment(user,text,nick){user=String(user||'viewer').slice(0,60);text=String(text||'').slice(0,300);if(text.trim())send({type:'comment',user,text,nick:String(nick||'').slice(0,60)})}
const uid=u=>u?String(u.uniqueId||u.displayId||'').replace(/^@/,''):'';
// Finds the visited creator's name and bio inside room info, whatever shape the lookup returned.
const nameKey=n=>String(n||'').normalize('NFKC').replace(/[\u{1F1E6}-\u{1F1FF}\u{E0000}-\u{E007F}\uFE0F\u200D]|\p{Extended_Pictographic}/gu,'').replace(/\s+/g,' ').trim().toLowerCase();
// Remembers which display name belongs to which username, so the phone can recognize a live by the name TikTok shows.
function learn(nick,user){
  const k=nameKey(nick);if(!k||!user||cfg.knownHosts[k]===user)return;
  if(!cfg.knownHosts||typeof cfg.knownHosts!=='object')cfg.knownHosts={};
  cfg.knownHosts[k]=user;const keys=Object.keys(cfg.knownHosts);if(keys.length>800)delete cfg.knownHosts[keys[0]];
  try{writeCfg()}catch(e){}
}
function hostProfile(info,host){
  const want=host.toLowerCase();let found=null,seen=0;
  (function walk(o,depth){if(found||!o||typeof o!=='object'||depth>6||++seen>4000)return;
    const id=String(o.display_id||o.uniqueId||o.unique_id||'').toLowerCase();
    if(id===want&&(o.nickname!==undefined||o.bio_description!==undefined||o.signature!==undefined)){found=o;return}
    for(const k in o)walk(o[k],depth+1)})(info,0);
  return{nick:String(found&&found.nickname||''),bio:String(found&&(found.bio_description||found.signature||found.bioDescription)||'')};
}
// A gift Angela sends on the visited live. Streak gifts report once, when the streak ends.
function onGift(d,host,hostInfo){
  if(!cfg.username||uid(d.user).toLowerCase()!==cfg.username.toLowerCase())return;
  const g=d.gift||{},x=d.extendedGiftInfo||{};
  if((g.type===1||x.type===1)&&!d.repeatEnd)return;
  const to=d.toUser&&uid(d.toUser)?d.toUser:null;
  const toId=to?uid(to):host;
  if(to)learn(to.nickname,toId);
  lastGift={to:toId.slice(0,40),toNick:String((to&&to.nickname)||d.toMemberNickname||hostInfo.nick||'').slice(0,60),gift:String(g.name||x.name||'Gift').slice(0,40),at:Date.now()};
  send({type:'gift',from:cfg.username,to:toId.slice(0,40),toNick:String((to&&to.nickname)||d.toMemberNickname||hostInfo.nick||'').slice(0,60),bio:String(to?to.bioDescription||'':hostInfo.bio).slice(0,400),gift:String(g.name||x.name||'Gift').slice(0,40),count:Math.max(1,Number(d.repeatCount)||1)});
}

let gen=0,activeConn=null,stopDirect=null;
async function direct(onLive,target,mode){
  target=target||cfg.username;mode=mode||'welcome';
  const {TikTokLiveConnection,WebcastEvent,ControlEvent}=require('tiktok-live-connector');
  const conn=new TikTokLiveConnection(target,{processInitialData:false,signApiKey:cfg.signApiKey||undefined});
  const my=gen;let ended;
  const finished=new Promise(r=>{ended=r});
  // The library reports stream errors as events. Without this listener one bad packet would end the app.
  conn.on(ControlEvent.ERROR,e=>console.log('TikTok connection: '+((e&&(e.info||e.message))||'error')));
  conn.on(ControlEvent.DISCONNECTED,()=>ended());
  let hostInfo={nick:'',bio:''};
  if(mode==='welcome')conn.on(WebcastEvent.CHAT,d=>{if(activeConn===conn)comment(uid(d.user)||(d.user&&d.user.nickname)||'viewer',d.comment||'',d.user&&d.user.nickname)});
  else conn.on(WebcastEvent.GIFT,d=>{if(activeConn===conn)try{onGift(d,target,hostInfo)}catch(e){console.log('Gift could not be read: '+e.message)}});
  await conn.connect();
  if(my!==gen){try{conn.disconnect()}catch(e){}return}
  activeConn=conn;stopDirect=ended;
  onLive();
  if(mode==='gifting'){hostInfo=hostProfile(conn.roomInfo,target);learn(hostInfo.nick,target);send({type:'visit',host:target});setStatus('WATCHING @'+target+' FOR @'+cfg.username+"'S GIFTS",true)}
  else setStatus('LIVE: @'+cfg.username,true);
  await finished;
  activeConn=null;stopDirect=null;
}
// Backups run only while the direct connection is down, so a comment is never read twice.
let backup=null;
function openBackup(name,url,onMessage){
  return new Promise((ok,fail)=>{
    const ws=new WebSocket(url,{handshakeTimeout:8000});let opened=false;
    ws.on('open',()=>{opened=true;backup={name,ws};ok()});
    ws.on('message',r=>{try{onMessage(JSON.parse(r))}catch(e){}});
    ws.on('error',e=>{if(!opened)fail(e)});
    ws.on('close',()=>{if(backup&&backup.ws===ws)backup=null;if(!opened)fail(new Error(name+' closed'))});
  });
}
const tikfinity=()=>openBackup('TIKFINITY','ws://127.0.0.1:21213/',m=>{
  if(m.event==='chat')comment(m.data.uniqueId||m.data.nickname||'viewer',m.data.comment||'');
});
const clean=t=>String(t||'').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&#39;|&apos;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();
const ssn=()=>openBackup('SOCIAL STREAM NINJA',process.env.SSN_URL||('wss://io.socialstream.ninja/join/'+encodeURIComponent(cfg.ssnSession)+'/4'),raw=>{
  const m=raw.overlayNinja||raw;
  if(m.chatname&&m.chatmessage&&(!m.type||m.type==='tiktok'))comment(clean(m.chatname),clean(m.chatmessage));
});
function dropBackup(){if(backup){const b=backup;backup=null;b.ws.close()}}
let wake=null;
const wait=ms=>new Promise(r=>{const t=setTimeout(()=>{wake=null;r()},ms);wake=()=>{clearTimeout(t);wake=null;r()}});
function restart(){gen++;dropBackup();if(activeConn){try{activeConn.disconnect()}catch(e){}}if(stopDirect)stopDirect();if(wake)wake()}
async function ensureBackup(){
  if(backup)return true;
  if(src()==='auto'||src()==='tikfinity'){try{await tikfinity();return true}catch(e){}}
  if((src()==='auto'||src()==='ssn')&&cfg.ssnSession){try{await ssn();return true}catch(e){console.log('Social Stream Ninja: '+(e.message||e))}}
  return false;
}
const src=()=>cfg.source||'auto';
async function cycle(){
  if(cfg.mode==='gifting'){
    dropBackup();
    if(!cfg.username){setStatus("ADD ANGELA'S TIKTOK USERNAME IN SETTINGS",false);return wait(RETRY)}
    if(!cfg.visiting){setStatus('GIFTING MODE: ENTER THE LIVE SHE IS VISITING',false);return wait(RETRY)}
    try{await direct(()=>{},cfg.visiting,'gifting');setStatus('@'+cfg.visiting+' ENDED THEIR LIVE',false);await wait(5000)}
    catch(e){console.log('Gifting Mode: '+(e&&e.message||e));setStatus('@'+cfg.visiting+' IS NOT LIVE. RETRYING',false);await wait(RETRY)}
    return;
  }
  const directAllowed=src()==='auto'||src()==='direct';
  if(directAllowed&&cfg.username){
    try{await direct(()=>dropBackup());setStatus('STREAM ENDED, WAITING',false);await wait(5000)}
    catch(e){console.log('Direct connection: '+(e&&e.message||e))}
  }
  if(await ensureBackup()&&backup){
    setStatus('READING CHAT VIA '+backup.name,true);
    const until=Date.now()+(directAllowed&&cfg.username?120000:RETRY);
    while(backup&&Date.now()<until)await wait(1000);
  }else{setStatus(directAllowed&&!cfg.username?'ADD HER TIKTOK USERNAME IN SETTINGS':'WAITING FOR CHAT CONNECTION',false);await wait(RETRY)}
}
async function run(){for(;;){try{await cycle()}catch(e){console.log('Connection loop: '+(e&&e.message||e));await wait(5000)}}}
(()=>{
  server.on('error',e=>{if(e.code==='EADDRINUSE'){console.log('Port '+cfg.port+' is already in use. If Globe Trek is already open, use that window.');process.exit(0)}console.log('Could not start: '+e.message);process.exit(1)});
  server.listen(cfg.port,cfg.phoneRemote?'0.0.0.0':'127.0.0.1',()=>console.log('Globe Trek ready: http://localhost:'+cfg.port+'\nKeep this window open while streaming.'));
  run();
})();

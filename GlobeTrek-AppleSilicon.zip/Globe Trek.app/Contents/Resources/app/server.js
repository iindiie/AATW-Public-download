// Runs on her PC. Reads TikTok LIVE comments and passes them to the globe page.
const http=require('http'),https=require('https'),fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const {WebSocketServer,WebSocket}=require('ws');
// The Mac app keeps settings in the user's Application Support folder, because the app bundle itself is read-only.
const DATA=process.env.GT_DATA_DIR||__dirname;
const CFG=path.join(DATA,'config.json');
if(!fs.existsSync(CFG)){try{fs.mkdirSync(DATA,{recursive:true});fs.copyFileSync(path.join(__dirname,'config.json'),CFG)}catch(e){}}
const CFG_DEFAULTS={username:'',source:'auto',signApiKey:'',ssnSession:'',mode:'welcome',visiting:'',phoneRemote:true,remoteKey:'',knownHosts:{},alsoGifters:[],recordTikTok:false,recordPhone:false,port:8787};
let cfg={...CFG_DEFAULTS};
// Welcome: viewers comment their city. Gifting: Angela's gifts fly the jet. Counting: Gifting plus a running count of her gifts.
const MODES=['welcome','gifting','counting'];
const giftLike=()=>cfg.mode==='gifting'||cfg.mode==='counting';
const writeCfg=()=>{const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG)};
try{cfg={...CFG_DEFAULTS,...JSON.parse(fs.readFileSync(CFG,'utf8'))}}catch(e){console.log('Settings file could not be read. Starting with defaults.')}
if(!/^[a-z0-9]{10}$/.test(cfg.remoteKey)){cfg.remoteKey=crypto.randomBytes(8).toString('hex').slice(0,10);try{fs.writeFileSync(CFG,JSON.stringify(cfg,null,2))}catch(e){}}
process.on('uncaughtException',e=>console.log('Unexpected error, still running: '+(e&&e.message||e)));
process.on('unhandledRejection',e=>console.log('Unexpected error, still running: '+(e&&e.message||e)));
const PUB=path.join(__dirname,'public');
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.jpg':'image/jpeg','.png':'image/png'};
const RETRY=30000;
let status={type:'status',text:'CONNECTING TO TIKTOK',live:false};

// Only the globe page itself may read or change connection details.
const localHost=h=>/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(h||'');
function trusted(req){
  if(!localHost(req.headers.host))return false;
  const o=req.headers.origin;if(!o)return true;
  try{return new URL(o).host===req.headers.host}catch(e){return false}
}
function lanUrls(){const out=[];for(const list of Object.values(os.networkInterfaces()))for(const a of list||[])if(a.family==='IPv4'&&!a.internal&&/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address))out.push('http://'+a.address+':'+cfg.port+'/remote?k='+cfg.remoteKey);return out}
function publicConfig(){return{recordTikTok:!!cfg.recordTikTok,capture:lastCapture&&{file:lastCapture.file,target:lastCapture.target,events:lastCapture.events,fields:lastCapture.fields.slice(0,40)},lastSeen,phone:cfg.phoneRemote?lanUrls():[],phoneRemote:!!cfg.phoneRemote,mode:MODES.includes(cfg.mode)?cfg.mode:'welcome',recordPhone:!!cfg.recordPhone,phoneTrace:phoneTrace&&{file:phoneTrace.file,count:phoneTrace.items.length},visiting:cfg.visiting||'',username:cfg.username||'',alsoGifters:cfg.alsoGifters||[],auditDir:AUDIT_DIR,historyFile:HISTORY,historyCount:histCount,source:cfg.source||'auto',hasSignKey:!!cfg.signApiKey,hasSsn:!!cfg.ssnSession}}
const cleanUser=(v,what)=>{const u=String(v).trim().replace(/^https?:\/\/(www\.)?tiktok\.com\//i,'').replace(/^@/,'').split(/[/?#]/)[0];if(u&&!/^[\w.]{1,40}$/.test(u))throw new Error('That '+what+' is not a valid TikTok username.');return u};
function saveConfig(b){
  if(typeof b.username==='string')cfg.username=cleanUser(b.username,'username');
  if(typeof b.visiting==='string')cfg.visiting=cleanUser(b.visiting,'creator name');
  if(b.mode!==undefined){if(!MODES.includes(b.mode))throw new Error('Unknown mode.');cfg.mode=b.mode}
  if(b.source!==undefined){if(!['auto','direct','tikfinity','ssn'].includes(b.source))throw new Error('Unknown connection source.');cfg.source=b.source}
  if(typeof b.signApiKey==='string'&&b.signApiKey.trim())cfg.signApiKey=b.signApiKey.trim();
  if(typeof b.ssnSession==='string'&&b.ssnSession.trim()){const v=b.ssnSession.trim(),m=v.match(/[?&]session=([^&#\s]+)/);cfg.ssnSession=m?decodeURIComponent(m[1]):v}
  if(b.alsoGifters!==undefined){const l=(Array.isArray(b.alsoGifters)?b.alsoGifters:String(b.alsoGifters).split(/[\s,]+/)).map(v=>cleanUser(v,'second account')).filter(Boolean);
    cfg.alsoGifters=[...new Set(l.map(v=>v.toLowerCase()))].filter(v=>v!==String(cfg.username).toLowerCase()).slice(0,4)}
  if(typeof b.phoneRemote==='boolean')cfg.phoneRemote=b.phoneRemote;
  if(typeof b.recordTikTok==='boolean')cfg.recordTikTok=b.recordTikTok;
  if(typeof b.recordPhone==='boolean')cfg.recordPhone=b.recordPhone;
  if(b.newRemoteKey)cfg.remoteKey=crypto.randomBytes(8).toString('hex').slice(0,10);
  if(b.forgetKeys){cfg.signApiKey='';cfg.ssnSession=''}
  const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG);
}
const server=http.createServer((req,res)=>{
  let url,pathname;
  try{url=new URL(req.url,'http://localhost');pathname=decodeURIComponent(url.pathname)}catch(e){res.statusCode=400;return res.end('Bad request')}
  const fromThisPc=/^(::1|127\.|::ffff:127\.)/.test(req.socket.remoteAddress||'');
  if(!fromThisPc){
    // Other devices on the network (her phone) may only use the phone remote.
    if(!cfg.phoneRemote||!pathname.startsWith('/remote')){res.statusCode=404;return res.end('Not found')}
    return remote(req,res,url,pathname);
  }
  if(pathname.startsWith('/remote'))return remote(req,res,url,pathname);
  if((url.pathname==='/config'||url.pathname==='/comment'||url.pathname==='/tally'||url.pathname==='/asks'||url.pathname==='/history')&&!trusted(req)){res.statusCode=403;return res.end('Not allowed')}
  if(process.env.GT_TEST==='1'&&url.pathname==='/test-gift'&&req.method==='POST'){let b='';req.on('data',d=>b+=d);req.on('end',()=>{const j=JSON.parse(b);if(j.clues){send({type:'clues',host:j.host,...j.clues});return res.end('ok')}if(j.record){const r=startRecording(j.host,'gifting');r.room(j.info);r.event('WebcastGiftMessage',j.d);r.close();return res.end('ok')}onGift(j.d,j.host,{...hostProfile(j.info,j.host),...(j.hostClues||{}),...(j.own?{own:true,saidBy:j.saidBy||{}}:{})});res.end('ok')});return}
  if(url.pathname==='/history'){
    if(req.method==='POST'){try{clearHistory();res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({count:0}))}catch(e){res.statusCode=500;return res.end('{}')}}
    res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="globe-trek-gift-history-'+new Date().toISOString().slice(0,10)+'.csv"');
    try{return res.end(fs.readFileSync(HISTORY))}catch(e){return res.end('\ufeff'+HIST_HEAD)}}
  if(url.pathname==='/tally'){res.setHeader('Content-Type','application/json');
    if(req.method==='POST'){tally=emptyTally();seenIds=new Set();saveTally();send({type:'tally',tally,reset:true});return res.end(JSON.stringify(tally))}
    return res.end(JSON.stringify(tally))}
  if(url.pathname==='/asks'&&req.method==='POST'){let b='';req.on('data',d=>{if(b.length<20000)b+=d});req.on('end',()=>{try{const j=JSON.parse(b);asks=(Array.isArray(j)?j:[]).slice(0,20).map(a=>({to:String(a.to||'').slice(0,70),nick:String(a.nick||'').slice(0,60),guess:String(a.guess||'').slice(0,80),how:String(a.how||'').slice(0,40),error:String(a.error||'').slice(0,120)})).filter(a=>a.to);res.end('ok')}catch(e){res.statusCode=400;res.end('bad')}});return}
  if(url.pathname==='/config'){
    res.setHeader('Content-Type','application/json');
    if(req.method==='GET')return res.end(JSON.stringify(publicConfig()));
    if(req.method==='POST'){let b='';req.on('data',d=>{if(b.length<8192)b+=d});req.on('end',()=>{try{saveConfig(JSON.parse(b));res.end(JSON.stringify(publicConfig()));restart()}catch(e){res.statusCode=400;res.end(JSON.stringify({error:e.message||'Those settings could not be saved.'}))}});return}
    res.statusCode=405;return res.end('{}');
  }
  if(req.method==='POST'&&url.pathname==='/comment'){ // manual backup and testing
    let b='';req.on('data',d=>{if(b.length<8192)b+=d});req.on('end',()=>{try{const m=JSON.parse(b);comment(m.user||'viewer',m.text);res.end('ok')}catch(e){res.statusCode=400;res.end('Send JSON with user and text')}});return;
  }
  const file=path.normalize(path.join(PUB,pathname==='/'?'index.html':pathname));
  if(!file.startsWith(PUB+path.sep)||req.method!=='GET'){res.statusCode=403;return res.end()}
  fs.readFile(file,(e,d)=>{if(e){res.statusCode=404;return res.end('Not found')}res.setHeader('Content-Type',TYPES[path.extname(file)]||'application/octet-stream');res.end(d)});
});
// ---------- Gift Count Mode: running totals of Angela's gifts, kept across restarts ----------
const TALLY=path.join(DATA,'gift-tally.json');
const emptyTally=()=>({gifts:0,coins:0,tiktokGifts:0,phoneGifts:0,byGift:{},byCreator:{},byGifter:{},startedAt:new Date().toISOString()});
let tally=emptyTally(),seenIds=new Set(),tallyTimer=null;
try{tally={...emptyTally(),...JSON.parse(fs.readFileSync(TALLY,'utf8'))}}catch(e){}
function saveTally(){if(!tallyTimer)tallyTimer=setTimeout(()=>{tallyTimer=null;try{const t=TALLY+'.tmp';fs.writeFileSync(t,JSON.stringify(tally));fs.renameSync(t,TALLY)}catch(e){}},800)}
// Running history: one line per gift, kept until someone clears it. Separate from the tally, which has its own reset.
const HISTORY=path.join(DATA,'gift-history.csv'),HIST_HEAD='Time,From,To (username),To (name),Gift,Count,Coins,Source,Live\r\n';
let histCount=0;try{histCount=Math.max(0,fs.readFileSync(HISTORY,'utf8').split('\n').filter(Boolean).length-1)}catch(e){}
const csv=v=>{let t=String(v==null?'':v).replace(/[\r\n]+/g,' ');if(/^[=+\-@\t]/.test(t))t="'"+t;return /[",]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t};
function addHistory(h){
  try{if(!fs.existsSync(HISTORY))fs.writeFileSync(HISTORY,'\ufeff'+HIST_HEAD);
    fs.appendFileSync(HISTORY,[new Date().toISOString(),h.from,h.to,h.toName,h.gift,h.count,h.coins,h.source,h.room].map(csv).join(',')+'\r\n');histCount++;
    send({type:'history',count:histCount})}catch(e){console.log('Gift history could not be saved: '+e.message)}
}
function clearHistory(){fs.writeFileSync(HISTORY,'\ufeff'+HIST_HEAD);histCount=0;send({type:'history',count:0})}
function addTally(g){
  if(g.id){if(seenIds.has(g.id))return;seenIds.add(g.id);if(seenIds.size>5000)seenIds=new Set([...seenIds].slice(-2000))}
  const n=Math.max(1,Math.min(100000,Math.round(Number(g.count)||1))),coins=Math.max(0,Math.min(1e8,Math.round(Number(g.coins)||0)));
  const name=String(g.gift||'Gift').slice(0,40),ck=(String(g.creator||'')||'name:'+nameKey(g.creatorName)).slice(0,60).toLowerCase();
  tally.gifts+=n;tally.coins+=coins;if(g.source==='phone')tally.phoneGifts+=n;else tally.tiktokGifts+=n;
  if(g.from){const fk=String(g.from).slice(0,40).toLowerCase(),bf=tally.byGifter[fk]||(tally.byGifter[fk]={count:0,coins:0});bf.count+=n;bf.coins+=coins}
  const bg=tally.byGift[name]||(tally.byGift[name]={count:0,coins:0});bg.count+=n;bg.coins+=coins;
  const bc=tally.byCreator[ck]||(tally.byCreator[ck]={user:String(g.creator||''),name:String(g.creatorName||'').slice(0,60),count:0,coins:0});bc.count+=n;bc.coins+=coins;if(g.creatorName)bc.name=String(g.creatorName).slice(0,60);
  saveTally();send({type:'tally',tally,last:{gift:name,count:n,coins,creator:bc.name||bc.user,source:g.source}});
}
function tallySummary(){const top=(o,k)=>Object.entries(o).sort((a,b)=>b[1].count-a[1].count).slice(0,5).map(([n,v])=>({name:k?(v.name||'@'+v.user):n,count:v.count,coins:v.coins}));return{gifts:tally.gifts,coins:tally.coins,phoneGifts:tally.phoneGifts,topGifts:top(tally.byGift),topCreators:top(tally.byCreator,1)}}
// Gifts the phone saw her send. Ignored while the PC is reading that same live straight from TikTok, so nothing counts twice.
function phoneGift(j){
  if(cfg.mode!=='counting')return{counted:false,reason:'The PC is not in Gift Count Mode.'};
  const name=String(j.creatorName||'').slice(0,60),k=nameKey(name),user=k&&cfg.knownHosts?cfg.knownHosts[k]:'';
  if(activeConn&&status.live&&ownLive)return{counted:false,reason:'The PC is counting her own live directly.'};
  if(activeConn&&status.live&&cfg.visiting&&(!name||(user&&user.toLowerCase()===cfg.visiting.toLowerCase())||k===nameKey(liveHostNick)))return{counted:false,reason:'The PC is counting this live directly.'};
  addTally({gift:j.gift,count:j.count,coins:j.coins,creator:user,creatorName:name,source:'phone'});
  addHistory({from:cfg.username,to:user,toName:name,gift:String(j.gift||'Gift'),count:Math.max(1,Number(j.count)||1),coins:Math.max(0,Number(j.coins)||0),source:'Phone',room:''});
  if(name||user)send({type:'gift',from:cfg.username,to:user||'',toNick:name,bio:'',gift:String(j.gift||'Gift').slice(0,40),count:Math.max(1,Number(j.count)||1),viaPhone:true});
  return{counted:true};
}
let phoneTrace=null;
function tracePhone(items){
  if(!cfg.recordPhone)return;
  if(!phoneTrace)phoneTrace={file:path.join(DATA,'phone-trace.json'),items:[]};
  for(const it of (Array.isArray(items)?items:[]).slice(0,50))phoneTrace.items.push({at:Date.now(),...(typeof it==='object'&&it?it:{text:String(it)})});
  if(phoneTrace.items.length>3000)phoneTrace.items=phoneTrace.items.slice(-3000);
  try{fs.writeFileSync(phoneTrace.file,JSON.stringify(phoneTrace.items,null,1))}catch(e){}
}
// ---------- Phone remote: lets Angela tell the PC which live she is on ----------
let asks=[];
let badTries=0,lockedUntil=0,lastGift=null,lastSeen=null,seenKey='';
setInterval(()=>{badTries=0},60000).unref();
function keyOk(k){const a=Buffer.from(String(k||'')),b=Buffer.from(cfg.remoteKey);return a.length===b.length&&crypto.timingSafeEqual(a,b)}
function json(res,code,o){res.statusCode=code;res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(o))}
// Turns a shared TikTok link, a profile link or a typed name into a username. Short links are followed on tiktok.com only.
function followLink(link,hops){
  return new Promise((ok,fail)=>{
    let u;try{u=new URL(link)}catch(e){return fail(new Error('That link could not be read.'))}
    const testHost=process.env.GT_TEST==='1'&&u.hostname==='127.0.0.1';
    if(!testHost&&!(u.protocol==='https:'&&/(^|\.)tiktok\.com$/i.test(u.hostname)))return fail(new Error('Only TikTok links can be used.'));
    const m=u.pathname.match(/\/@([\w.]{1,40})/);if(m)return ok(m[1]);
    if(hops>4)return fail(new Error('That link did not lead to a TikTok profile.'));
    const r=(testHost?http:https).request(u,{method:'GET',timeout:8000,headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'}},resp=>{resp.resume();const loc=resp.headers.location;if(resp.statusCode>=300&&resp.statusCode<400&&loc)followLink(new URL(loc,u).href,hops+1).then(ok,fail);else fail(new Error('That link did not lead to a TikTok profile.'))});
    r.on('timeout',()=>r.destroy(new Error('TikTok did not answer. Try the creator name instead.')));r.on('error',e=>fail(e));r.end();
  });
}
async function toUsername(input){
  const t=String(input||'').trim().slice(0,300);
  const link=t.match(/https?:\/\/\S+/);
  if(link)return followLink(link[0].replace(/[).,]+$/,''),0);
  return cleanUser(t,'creator name');
}
// What the phone app saw on the TikTok live screen. Pick the creator: a learned display name first, then an @handle shown in the header area.
function seen(j){
  const arr=v=>Array.isArray(v)?v.slice(0,80).map(x=>String(x).slice(0,80)):[];
  const top=arr(j.top),handles=arr(j.handles).map(h=>h.replace(/^@/,'')).filter(h=>/^[\w.]{2,24}$/.test(h)),sample=arr(j.sample);
  lastSeen={top:top.slice(0,8),handles:handles.slice(0,8),sample:sample.slice(0,40),at:Date.now(),result:''};
  if(!giftLike()){lastSeen.result='PC is in Welcome Mode';return{result:lastSeen.result}}
  let user='',name='';
  for(const t of top){const k=nameKey(t);if(cfg.knownHosts&&cfg.knownHosts[k]){user=cfg.knownHosts[k];name=t;break}}
  if(!user){const h=top.map(t=>t.match(/^@([\w.]{2,24})$/)).find(Boolean);if(h)user=h[1]}
  if(!user){lastSeen.result=top[0]?'Not recognized yet: '+top[0]:'No creator name found on screen';return{result:lastSeen.result,needShare:!!top[0]}}
  if(cfg.username&&user.toLowerCase()===cfg.username.toLowerCase()){lastSeen.result='Her own live';if(cfg.visiting){cfg.visiting='';writeCfg();restart();send({type:'config'})}return{result:lastSeen.result,visiting:''}}
  lastSeen.result='Following @'+user;
  if(user.toLowerCase()!==String(cfg.visiting).toLowerCase()){cfg.visiting=user;writeCfg();restart();send({type:'config'})}
  return{result:lastSeen.result,visiting:user,name};
}
function remote(req,res,url,pathname){
  if(!cfg.phoneRemote)return json(res,404,{error:'The phone remote is turned off on the PC.'});
  if(req.method==='GET'&&pathname==='/remote/logo.png'){res.setHeader('Content-Type','image/png');return fs.createReadStream(path.join(PUB,'assets','icon.png')).on('error',()=>res.end()).pipe(res)}
  if(Date.now()<lockedUntil)return json(res,429,{error:'Too many wrong tries. Wait a minute.'});
  const k=url.searchParams.get('k');
  if(!keyOk(k)){if(++badTries>10)lockedUntil=Date.now()+60000;return json(res,403,{error:'This remote link is out of date. Scan the new code on the PC.'})}
  if(req.method==='GET'&&pathname==='/remote'){res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');return fs.createReadStream(path.join(__dirname,'remote.html')).on('error',()=>res.end('Remote page missing.')).pipe(res)}
  if(req.method==='GET'&&pathname==='/remote/logo.png'){res.setHeader('Content-Type','image/png');return fs.createReadStream(path.join(PUB,'assets','icon.png')).on('error',()=>res.end()).pipe(res)}
  if(req.method==='GET'&&pathname==='/remote/status')return json(res,200,{tally:cfg.mode==='counting'?tallySummary():null,recordPhone:!!cfg.recordPhone,asks,seen:lastSeen&&lastSeen.result,mode:cfg.mode,visiting:cfg.visiting,status:status.text,live:status.live,lastGift});
  if(req.method==='POST'&&(pathname==='/remote/gift'||pathname==='/remote/trace')){
    let b='';req.on('data',d=>{if(b.length<60000)b+=d});
    req.on('end',()=>{try{const j=JSON.parse(b||'{}');if(pathname==='/remote/trace'){tracePhone(j.items);return json(res,200,{ok:true})}json(res,200,phoneGift(j))}catch(e){json(res,400,{error:'The phone sent something unreadable.'})}});
    return;
  }
  if(req.method==='POST'&&pathname==='/remote/answer'){
    let b='';req.on('data',d=>{if(b.length<4096)b+=d});
    req.on('end',()=>{try{const j=JSON.parse(b||'{}');const to=String(j.to||'').replace(/^@/,'').slice(0,70);const city=String(j.city||'').trim().slice(0,80);
      if(!to||(!j.confirm&&!city))throw new Error('Type a city, or confirm the guess.');
      send({type:'answer',to,confirm:!!j.confirm,city});asks=asks.filter(a=>a.to.toLowerCase()!==to.toLowerCase());json(res,200,{ok:true})}catch(e){json(res,400,{error:e.message})}});
    return;
  }
  if(req.method==='POST'&&pathname==='/remote/seen'){
    let b='';req.on('data',d=>{if(b.length<16384)b+=d});
    req.on('end',()=>{try{json(res,200,seen(JSON.parse(b||'{}')))}catch(e){json(res,400,{error:'The phone sent something unreadable.'})}});
    return;
  }
  if(req.method==='POST'&&pathname==='/remote/visit'){
    let b='';req.on('data',d=>{if(b.length<4096)b+=d});
    req.on('end',async()=>{try{const j=JSON.parse(b||'{}');
      if(j.stop){cfg.visiting=''}else{const u=await toUsername(j.link);if(!u)throw new Error('Paste a TikTok live link or type the creator name.');cfg.visiting=cfg.username&&u.toLowerCase()===cfg.username.toLowerCase()?'':u;if(!giftLike())cfg.mode='gifting'}
      const tmp=CFG+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));fs.renameSync(tmp,CFG);restart();send({type:'config'});
      json(res,200,{mode:cfg.mode,visiting:cfg.visiting})}catch(e){json(res,400,{error:e.message||'That did not work.'})}});
    return;
  }
  json(res,404,{error:'Not found'});
}
const wss=new WebSocketServer({server,path:'/events',verifyClient:i=>trusted(i.req)});
wss.on('error',()=>{}); // the listen error is handled once, on the server below
wss.on('connection',ws=>ws.send(JSON.stringify(status)));
function send(m){const t=JSON.stringify(m);for(const c of wss.clients)if(c.readyState===WebSocket.OPEN)c.send(t)}
function setStatus(text,live){status={type:'status',text,live:!!live};send(status);console.log('['+new Date().toLocaleTimeString()+'] '+text)}
function comment(user,text,nick){user=String(user||'viewer').slice(0,60);text=String(text||'').slice(0,300);if(text.trim())send({type:'comment',user,text,nick:String(nick||'').slice(0,60)})}
const uid=u=>u?String(u.uniqueId||u.displayId||'').replace(/^@/,''):'';
// Finds the visited creator's name and bio inside room info, whatever shape the lookup returned.
const nameKey=n=>String(n||'').normalize('NFKC').replace(/[\u{1F1E6}-\u{1F1FF}\u{E0000}-\u{E007F}\uFE0F\u200D]|\p{Extended_Pictographic}/gu,'').replace(/\s+/g,' ').trim().toLowerCase();
// Remembers which display name belongs to which username, so the phone can recognize a live by the name TikTok shows.
function learn(nick,user){
  const k=nameKey(nick);if(!k||!user||cfg.knownHosts[k]===user)return;
  if(!cfg.knownHosts||typeof cfg.knownHosts!=='object')cfg.knownHosts={};
  cfg.knownHosts[k]=user;const keys=Object.keys(cfg.knownHosts);if(keys.length>800)delete cfg.knownHosts[keys[0]];
  try{writeCfg()}catch(e){}
}
function hostProfile(info,host){
  const want=host.toLowerCase();let found=null,seen=0;
  (function walk(o,depth){if(found||!o||typeof o!=='object'||depth>6||++seen>4000)return;
    const id=String(o.display_id||o.uniqueId||o.unique_id||'').toLowerCase();
    if(id===want&&(o.nickname!==undefined||o.bio_description!==undefined||o.signature!==undefined)){found=o;return}
    for(const k in o)walk(o[k],depth+1)})(info,0);
  return{nick:String(found&&found.nickname||''),bio:String(found&&(found.bio_description||found.signature||found.bioDescription)||'')};
}
function roomTitle(info){let t='';(function walk(o,d){if(t||!o||typeof o!=='object'||d>3)return;if(typeof o.title==='string'&&o.title.trim()){t=o.title.trim();return}for(const k in o)walk(o[k],d+1)})(info,0);return t.slice(0,200)}
// ---------- Recorder: saves what TikTok sends, to learn which fields carry a location ----------
let lastCapture=null;
const GEO=/region|country|locat|city|geo|area|nation|address|timezone|lang/i;
function geoFields(obj,base,out){
  (function walk(o,p,d){if(!o||typeof o!=='object'||d>9||out.length>60)return;
    for(const k in o){const v=o[k],pth=p?p+'.'+k:k;
      if(v!==null&&typeof v!=='object'&&GEO.test(k)&&String(v).trim()&&String(v)!=='0'){const line=pth+' = '+String(v).slice(0,80);if(!out.includes(line))out.push(line)}
      else if(typeof v==='object')walk(v,pth,d+1)}})(obj,base,0);
  return out;
}
function startRecording(target,mode){
  const file=path.join(DATA,'tiktok-capture.json');
  const data={target,mode,startedAt:new Date().toISOString(),roomInfo:null,events:[]};const counts={};const fields=[];
  let timer=null;const flush=()=>{timer=null;try{fs.writeFileSync(file,JSON.stringify(data,(k,v)=>typeof v==='bigint'?String(v):v,1))}catch(e){}};
  const later=()=>{if(!timer)timer=setTimeout(flush,1500)};
  lastCapture={file,target,fields,events:0,at:Date.now()};
  console.log('Recording what TikTok sends to '+file);
  return{
    room(info){data.roomInfo=info;geoFields(info,'roomInfo',fields);later()},
    event(method,d){counts[method]=(counts[method]||0)+1;if(counts[method]>40||data.events.length>=600)return;
      data.events.push({method,at:Date.now(),data:d});lastCapture.events=data.events.length;geoFields(d,method,fields);later()},
    close(){if(timer){clearTimeout(timer);flush()}}
  };
}
// Every gift TikTok reports in the watched live is written to a daily audit file, counted or not, so a count can be checked afterwards.
const AUDIT_DIR=path.join(DATA,'gift-audit');let auditBuf=[],auditTimer=null;
function audit(o){
  try{auditBuf.push(JSON.stringify({t:new Date().toISOString(),...o}));
    if(!auditTimer)auditTimer=setTimeout(()=>{auditTimer=null;const lines=auditBuf.join('\n')+'\n';auditBuf=[];
      try{fs.mkdirSync(AUDIT_DIR,{recursive:true});const f=path.join(AUDIT_DIR,new Date().toISOString().slice(0,10)+'.jsonl');
        let size=0;try{size=fs.statSync(f).size}catch(e){}if(size<200e6)fs.appendFileSync(f,lines)}catch(e){}},500)}catch(e){}
}
// Gifting accounts are matched by username and by TikTok's numeric account id, in case a message arrives without the username.
const gifterIds=new Map();
// When the connection drops and comes back on the same live, TikTok's recent messages are replayed so gifts sent during the gap still count.
const session={target:'',start:0,droppedAt:0};
function senderOf(d){
  const u=uid(d.user),id=String(d.user&&d.user.userId||'');
  if(u&&isGifter(u)){if(id)gifterIds.set(id,u);return u}
  if(!u&&id&&gifterIds.has(id))return gifterIds.get(id);
  return '';
}
// Streak gifts: TikTok reports a running total while the streak goes. The count grows with every report, so a lost
// final message never loses the streak. The flight starts when the streak ends, or 6 seconds after its last report.
const streaks=new Map();let giftMsgs=new Set();
function streakKey(d,from){return from.toLowerCase()+'|'+(d.groupId&&d.groupId!=='0'?d.groupId:(d.giftId+'|'+uid(d.toUser)))}
function onGift(d,host,hostInfo){
  const g=d.gift||{},x=d.extendedGiftInfo||{},type=Number(g.type||x.type)||0,rc=Math.max(1,Number(d.repeatCount)||1);
  const from=cfg.username?senderOf(d):'';
  const row={msg:String(d.common&&d.common.msgId||''),group:String(d.groupId||''),from:uid(d.user),fromId:String(d.user&&d.user.userId||''),to:uid(d.toUser),toNick:String(d.toUser&&d.toUser.nickname||d.toMemberNickname||''),gift:String(g.name||x.name||''),giftId:String(d.giftId||''),type,coins:Number(g.diamondCount||x.diamondCount)||0,repeat:Number(d.repeatCount)||0,groupCount:Number(d.groupCount)||0,combo:Number(d.comboCount)||0,end:!!d.repeatEnd,room:host,toMember:String(d.toMemberId||d.toMemberIdInt||''),multi:!!d.multiGenerateMessage,sendType:String(d.sendType||''),sent:String(d.common&&d.common.createTime||'')};
  const ct=Number(d.common&&d.common.createTime)||0;
  if(ct&&session.start&&ct<session.start-2000){audit({...row,result:'sent before the app started watching'});return}
  if(!from){audit({...row,result:'not one of her accounts'});return}
  if(type!==1){
    if(row.msg){if(giftMsgs.has(row.msg)){audit({...row,result:'repeat of a message already counted'});return}giftMsgs.add(row.msg);if(giftMsgs.size>20000)giftMsgs=new Set([...giftMsgs].slice(-10000))}
    audit({...row,result:'counted',add:rc});return deliver(d,host,hostInfo,from,rc,row.msg)}
  const k=streakKey(d,from);let st=streaks.get(k);
  if(!st){st={counted:0,done:false,timer:null};streaks.set(k,st)}
  const add=Math.max(0,rc-st.counted);
  audit({...row,result:add?'counted':'streak update, already counted',add});
  if(add){st.counted=rc;tallyOnly(d,host,hostInfo,from,add,k+':'+rc)}
  clearTimeout(st.timer);
  const finish=()=>{clearTimeout(st.timer);if(!st.done){st.done=true;historyOnly(d,host,hostInfo,from,st.counted);flyOnly(d,host,hostInfo,from,st.counted)}setTimeout(()=>{if(streaks.get(k)===st)streaks.delete(k)},45*60000)};
  if(d.repeatEnd)finish();else st.timer=setTimeout(()=>{audit({...row,result:'streak ended without a final message',total:st.counted});finish()},6000);
}
const isGifterName=u=>!!u&&isGifter(u);
function deliver(d,host,hostInfo,from,n,id){tallyOnly(d,host,hostInfo,from,n,id);historyOnly(d,host,hostInfo,from,n);flyOnly(d,host,hostInfo,from,n)}
function historyOnly(d,host,hostInfo,from,n){
  const g=d.gift||{},x=d.extendedGiftInfo||{},r=recipient(d,host,hostInfo);
  if(r.id&&r.id.toLowerCase()===from.toLowerCase())return;
  addHistory({from,to:r.id,toName:r.name,gift:String(g.name||x.name||'Gift').trim(),count:n,coins:(Number(g.diamondCount||x.diamondCount)||0)*n,source:'TikTok',room:host});
}
// Who the gift went to.
function recipient(d,host,hostInfo){
  const to=d.toUser&&uid(d.toUser)?d.toUser:null;
  if(hostInfo.own){const nick=String((to&&to.nickname)||d.toMemberNickname||'').slice(0,60),known=nick&&cfg.knownHosts?cfg.knownHosts[nameKey(nick)]||'':'';
    const gid=to?uid(to):known;return{to,id:gid,nick,toHer:!!gid&&gid.toLowerCase()===cfg.username.toLowerCase(),name:nick||(gid?'':'Guest')}}
  const id=to?uid(to):host,nick=String((to&&to.nickname)||d.toMemberNickname||hostInfo.nick||'').slice(0,60);
  return{to,id,nick,toHer:false,name:nick};
}
function tallyOnly(d,host,hostInfo,from,n,id){
  if(cfg.mode!=='counting')return;
  const g=d.gift||{},x=d.extendedGiftInfo||{},r=recipient(d,host,hostInfo);
  if(r.id&&r.id.toLowerCase()===from.toLowerCase())return;
  addTally({id,gift:String(g.name||x.name||'Gift'),count:n,coins:(Number(g.diamondCount||x.diamond_count||x.diamondCount)||0)*n,creator:r.id,creatorName:r.name,source:'tiktok',from});
}
function flyOnly(d,host,hostInfo,from,n){
  const g=d.gift||{},x=d.extendedGiftInfo||{},r=recipient(d,host,hostInfo),gname=String(g.name||x.name||'Gift').slice(0,40);
  if(r.id&&r.id.toLowerCase()===from.toLowerCase())return;
  if(r.to&&!r.toHer)learn(r.to.nickname,r.id);
  if(hostInfo.own){
    if(r.toHer||(!r.id&&!r.nick))return;
    lastGift={to:r.id.slice(0,40),toNick:r.nick,gift:gname,at:Date.now()};
    send({type:'gift',from,to:r.id.slice(0,40),toNick:r.nick,bio:String(r.to&&r.to.bioDescription||'').slice(0,400),clues:{title:'',pinned:'',intro:'',said:(hostInfo.saidBy[r.id.toLowerCase()]||[]).slice(-6)},gift:gname,count:n});
    return;
  }
  const toHost=r.id.toLowerCase()===String(host).toLowerCase();
  lastGift={to:r.id.slice(0,40),toNick:r.nick,gift:gname,at:Date.now()};
  send({type:'gift',from,to:r.id.slice(0,40),toNick:r.nick,bio:String(r.to?r.to.bioDescription||'':hostInfo.bio).slice(0,400),clues:toHost?{title:hostInfo.title||'',pinned:hostInfo.pinned||'',intro:hostInfo.intro||'',said:(hostInfo.said||[]).slice(-6)}:null,gift:gname,count:n});
}

const isGifter=u=>{u=String(u||'').toLowerCase();return !!u&&(u===String(cfg.username).toLowerCase()||(cfg.alsoGifters||[]).includes(u))};
let ownLive=false,gen=0,activeConn=null,stopDirect=null,liveHostNick='';
async function direct(onLive,target,mode){
  target=target||cfg.username;mode=mode||'welcome';
  const {TikTokLiveConnection,WebcastEvent,ControlEvent}=require('tiktok-live-connector');
  const resume=session.target===target&&session.droppedAt&&Date.now()-session.droppedAt<15*60000;
  if(!resume){session.target=target;session.start=0}
  const conn=new TikTokLiveConnection(target,{processInitialData:!!resume,signApiKey:cfg.signApiKey||undefined});
  const my=gen;let ended;
  const finished=new Promise(r=>{ended=r});
  // The library reports stream errors as events. Without this listener one bad packet would end the app.
  conn.on(ControlEvent.ERROR,e=>{const m=(e&&(e.info||e.message))||'error';console.log('TikTok connection: '+m);audit({ev:'connection error',room:target,reason:String(m).slice(0,200)})});
  conn.on(ControlEvent.DISCONNECTED,()=>{if(activeConn===conn){session.droppedAt=Date.now();audit({ev:'disconnected',room:target})}ended()});
  let hostInfo={nick:'',bio:'',title:'',pinned:'',intro:'',said:[],own:mode==='own',saidBy:{}};
  const hostIs=u=>uid(u).toLowerCase()===String(target).toLowerCase();
  const sendClues=()=>send({type:'clues',host:target,nick:hostInfo.nick,bio:hostInfo.bio,title:hostInfo.title,pinned:hostInfo.pinned,intro:hostInfo.intro,said:hostInfo.said.slice(-6)});
  const rec=cfg.recordTikTok?startRecording(target,mode):null;
  if(rec)conn.on(ControlEvent.DECODED_DATA,(method,decoded)=>rec.event(method,decoded&&decoded.data));
  if(mode==='gifting'){
    // Places the creator mentions themselves: their own comments, the pinned comment and the live intro.
    conn.on(WebcastEvent.CHAT,d=>{if(activeConn===conn&&hostIs(d.user)){hostInfo.said.push(String(d.comment||'').slice(0,200));if(hostInfo.said.length>12)hostInfo.said.shift();sendClues()}});
    conn.on(WebcastEvent.ROOM_PIN,d=>{const c=d&&d.chatMessage;if(activeConn===conn&&c&&c.comment){hostInfo.pinned=String(c.comment).slice(0,200);sendClues()}});
    conn.on(WebcastEvent.LIVE_INTRO,d=>{if(activeConn===conn&&d&&d.content){hostInfo.intro=String(d.content).slice(0,300);sendClues()}});
  }
  if(mode==='own'){
    // In her own live, a guest's own comments are a clue to where they are.
    conn.on(WebcastEvent.CHAT,d=>{if(activeConn!==conn)return;const u=uid(d.user).toLowerCase();if(!u||isGifter(u))return;
      const a=hostInfo.saidBy[u]||(hostInfo.saidBy[u]=[]);a.push(String(d.comment||'').slice(0,200));if(a.length>6)a.shift();
      const keys=Object.keys(hostInfo.saidBy);if(keys.length>400)delete hostInfo.saidBy[keys[0]]});
  }
  if(mode==='welcome')conn.on(WebcastEvent.CHAT,d=>{if(activeConn===conn)comment(uid(d.user)||(d.user&&d.user.nickname)||'viewer',d.comment||'',d.user&&d.user.nickname)});
  else conn.on(WebcastEvent.GIFT,d=>{if(my===gen)try{onGift(d,target,hostInfo)}catch(e){console.log('Gift could not be read: '+e.message)}});
  await conn.connect();
  if(my!==gen){try{conn.disconnect()}catch(e){}return}
  activeConn=conn;stopDirect=ended;
  if(!session.start)session.start=Date.now();
  audit({ev:resume?'reconnected':'connected',room:target,mode,gapSeconds:resume?Math.round((Date.now()-session.droppedAt)/1000):0});session.droppedAt=0;
  onLive();
  if(rec)rec.room(conn.roomInfo);
  if(mode==='own'){ownLive=true;liveHostNick='';setStatus(cfg.mode==='counting'?'COUNTING @'+cfg.username+"'S GIFTS IN HER OWN LIVE":'WATCHING @'+cfg.username+"'S LIVE FOR GIFTS TO HER GUESTS",true)}
  else if(mode==='gifting'){liveHostNick=hostProfile(conn.roomInfo,target).nick;Object.assign(hostInfo,hostProfile(conn.roomInfo,target),{title:roomTitle(conn.roomInfo)});sendClues();learn(hostInfo.nick,target);send({type:'visit',host:target});setStatus(cfg.mode==='counting'?'COUNTING @'+cfg.username+"'S GIFTS ON @"+target:'WATCHING @'+target+' FOR @'+cfg.username+"'S GIFTS",true)}
  else setStatus('LIVE: @'+cfg.username,true);
  await finished;
  if(rec)rec.close();
  activeConn=null;stopDirect=null;ownLive=false;
}
// Backups run only while the direct connection is down, so a comment is never read twice.
let backup=null;
function openBackup(name,url,onMessage){
  return new Promise((ok,fail)=>{
    const ws=new WebSocket(url,{handshakeTimeout:8000});let opened=false;
    ws.on('open',()=>{opened=true;backup={name,ws};ok()});
    ws.on('message',r=>{try{onMessage(JSON.parse(r))}catch(e){}});
    ws.on('error',e=>{if(!opened)fail(e)});
    ws.on('close',()=>{if(backup&&backup.ws===ws)backup=null;if(!opened)fail(new Error(name+' closed'))});
  });
}
const tikfinity=()=>openBackup('TIKFINITY','ws://127.0.0.1:21213/',m=>{
  if(m.event==='chat')comment(m.data.uniqueId||m.data.nickname||'viewer',m.data.comment||'');
});
const clean=t=>String(t||'').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&#39;|&apos;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();
const ssn=()=>openBackup('SOCIAL STREAM NINJA',process.env.SSN_URL||('wss://io.socialstream.ninja/join/'+encodeURIComponent(cfg.ssnSession)+'/4'),raw=>{
  const m=raw.overlayNinja||raw;
  if(m.chatname&&m.chatmessage&&(!m.type||m.type==='tiktok'))comment(clean(m.chatname),clean(m.chatmessage));
});
function dropBackup(){if(backup){const b=backup;backup=null;b.ws.close()}}
let wake=null;
const wait=ms=>new Promise(r=>{const t=setTimeout(()=>{wake=null;r()},ms);wake=()=>{clearTimeout(t);wake=null;r()}});
function restart(){gen++;dropBackup();if(activeConn){try{activeConn.disconnect()}catch(e){}}if(stopDirect)stopDirect();if(wake)wake()}
async function ensureBackup(){
  if(backup)return true;
  if(src()==='auto'||src()==='tikfinity'){try{await tikfinity();return true}catch(e){}}
  if((src()==='auto'||src()==='ssn')&&cfg.ssnSession){try{await ssn();return true}catch(e){console.log('Social Stream Ninja: '+(e.message||e))}}
  return false;
}
const src=()=>cfg.source||'auto';
async function cycle(){
  if(giftLike()){
    dropBackup();
    if(!cfg.username){setStatus("ADD ANGELA'S TIKTOK USERNAME IN SETTINGS",false);return wait(RETRY)}
    // No live shared: watch her own live, where she gifts the guests she brings up.
    const own=!cfg.visiting||cfg.visiting.toLowerCase()===cfg.username.toLowerCase(),target=own?cfg.username:cfg.visiting;
    try{await direct(()=>{},target,own?'own':'gifting');
      if(own)setStatus('@'+cfg.username+' ENDED HER LIVE',false);else{setStatus('@'+target+' ENDED THEIR LIVE. BACK TO HER OWN LIVE',false);if(cfg.visiting===target){cfg.visiting='';writeCfg();send({type:'config'})}}
      await wait(1500)}
    catch(e){console.log('Gifting Mode: '+(e&&e.message||e));audit({ev:'could not connect',room:cfg.visiting||cfg.username,reason:String(e&&e.message||e).slice(0,200)});
      if(own){setStatus('@'+cfg.username+(cfg.mode==='counting'?' IS NOT LIVE. COUNTING FROM HER PHONE':' IS NOT LIVE. SHARE THE LIVE SHE IS VISITING'),false);await wait(15000)}
      else{setStatus('@'+target+' IS NOT LIVE. WATCHING HER OWN LIVE',false);if(cfg.visiting===target){cfg.visiting='';writeCfg();send({type:'config'})}await wait(3000)}}
    return;
  }
  const directAllowed=src()==='auto'||src()==='direct';
  if(directAllowed&&cfg.username){
    try{await direct(()=>dropBackup());setStatus('STREAM ENDED, WAITING',false);await wait(5000)}
    catch(e){console.log('Direct connection: '+(e&&e.message||e))}
  }
  if(await ensureBackup()&&backup){
    setStatus('READING CHAT VIA '+backup.name,true);
    const until=Date.now()+(directAllowed&&cfg.username?120000:RETRY);
    while(backup&&Date.now()<until)await wait(1000);
  }else{setStatus(directAllowed&&!cfg.username?'ADD HER TIKTOK USERNAME IN SETTINGS':'WAITING FOR CHAT CONNECTION',false);await wait(RETRY)}
}
async function run(){for(;;){try{await cycle()}catch(e){console.log('Connection loop: '+(e&&e.message||e));await wait(5000)}}}
(()=>{
  server.on('error',e=>{if(e.code==='EADDRINUSE'){console.log('Port '+cfg.port+' is already in use. If Globe Trek is already open, use that window.');process.exit(0)}console.log('Could not start: '+e.message);process.exit(1)});
  server.listen(cfg.port,cfg.phoneRemote?'0.0.0.0':'127.0.0.1',()=>console.log('Globe Trek ready: http://localhost:'+cfg.port+'\nKeep this window open while streaming.'));
  run();
})();
